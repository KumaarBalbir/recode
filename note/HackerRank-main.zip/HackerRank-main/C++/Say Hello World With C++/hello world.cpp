/* Author: Isaac Asante
 * HackerRank URL for this exercise: https://www.hackerrank.com/challenges/cpp-hello-world/problem
 * Original video explanation: https://www.youtube.com/watch?v=xwpIZIJ6hPc
 * Last verified on: April 17, 2021
 */

/* IMPORTANT:
 * Below is the full code for the solution.
 */

#include <iostream>
#include <cstdio>
using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}
